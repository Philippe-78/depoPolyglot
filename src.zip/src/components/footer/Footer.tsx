export const Footer=()=>{
    return (
        <div className="footer">
        <h1>Pied de Page</h1>
        </div>
    );
}