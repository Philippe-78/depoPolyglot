import React from "react";

//export function Header(){}
export const Header=()=>{
    return (
        <div className="header">
        <h1>EN TÊTE</h1>
        </div>
    );
}