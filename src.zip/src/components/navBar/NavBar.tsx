export const NavBar=()=>{
    return (
        <div className="navBar">
        <h2>Barre de navigation</h2>
        </div>
    );
}