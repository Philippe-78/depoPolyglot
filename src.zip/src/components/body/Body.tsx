export const Body=()=>{
    return (
        <div  className="body">
             <h1>Corps de page</h1>
        <p className="espaceText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae expedita repudiandae, porro cumque sequi delectus in dolores nobis vel. Distinctio nesciunt ad eaque tempora quasi ipsum doloremque itaque expedita obcaecati?
        Eveniet distinctio nostrum ex tenetur, ut doloremque doloribus, corporis maiores accusamus inventore aperiam a, nihil odit repellendus possimus facilis quae soluta commodi exercitationem quasi perspiciatis consequuntur beatae? Cupiditate, laborum inventore.
        Est maiores, sit voluptatibus animi blanditiis accusamus architecto asperiores ipsum quod impedit delectus nisi deserunt velit eum adipisci aliquid aut, earum magnam ea assumenda sequi. Magni inventore saepe eos esse!
        Atque praesentium illum maiores esse placeat repellat voluptatem dignissimos, a reiciendis, rem molestias eius quibusdam voluptatibus iure, consequatur sit alias delectus quasi modi ut odio dolores. Quasi magnam dolorem voluptate.
        Minima magni nostrum aliquid, quidem odit repudiandae eos pariatur provident doloribus sapiente cumque repellat quia debitis harum vel recusandae totam illo? Reiciendis sunt eaque quas saepe ipsa cum, corporis quisquam? ipsum, dolor sit amet consectetur adipisicing elit. Ipsa et in porro adipisci autem modi nam, voluptates ipsum officiis! Temporibus architecto impedit distinctio, quidem ipsam necessitatibus fugit officia perferendis at!orem*5
             </p>
        </div>
        
    );
}