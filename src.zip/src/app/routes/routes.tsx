import { Route, Routes } from "react-router-dom";
import Home from "../pages/home";
import SearchResult from "../pages/SearchResult";
import { PageRoutes } from "./constantsRoutes";

const RoutesCmpt = () => (
  <Routes>
    <Route  path={PageRoutes.ROOT}
     element={<Home />} />
    <Route path={PageRoutes.SEARCH_RESULT}
     element={<SearchResult />} />
  </Routes>
);

export default RoutesCmpt;
