export enum PageRoutes {
    ROOT = '/',
    SEARCH_RESULT = '/searchResult',
    DOC_VIEW = '/docView',
    ERROR_SERVER = '/errorServer',
  
}