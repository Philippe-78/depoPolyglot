
import './App.css'
import { Footer } from '../components/footer/Footer'
import { Header } from '../components/header/Header'
import { NavBar } from '../components/navBar/NavBar'
import Home from './pages/home'

function App() {
  

  return (
    <div className='app'>
      <Header/>
      <div className="main">
      <NavBar/>
      <Home/>
      </div>
      <Footer/>
    </div>
  )
}

export default App
