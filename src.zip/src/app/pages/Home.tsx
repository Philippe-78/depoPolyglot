import { Body } from "../../components/body/Body";

export default function Home(){
    return(<>
        <h1>je suis la première page</h1>
        <Body/>
        </>
    )
}