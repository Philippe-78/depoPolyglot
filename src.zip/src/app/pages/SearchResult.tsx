export default function SearchResult(){
    return(
        <h1>je suis la  page de recherche</h1>
    )
}